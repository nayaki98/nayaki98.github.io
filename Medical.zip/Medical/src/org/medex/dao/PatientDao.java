package org.medex.dao;

import org.medex.beans.Patient;

public interface PatientDao {
	
	public String insertRegistration(Patient p); //register patient
    /*public boolean insertAppointment(Appointment a);
    public Appointment selectAppointment(Appointment a);
    public boolean deleteAppointment(int appid);*/

}
