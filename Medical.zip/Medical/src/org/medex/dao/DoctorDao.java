package org.medex.dao;

import org.medex.beans.Doctor;

public interface DoctorDao {
	String insertRegistration(Doctor d);

}
