package org.medex.service;

import org.medex.beans.Doctor;

public interface DoctorService {
	String registerDoctor(Doctor d);

}
