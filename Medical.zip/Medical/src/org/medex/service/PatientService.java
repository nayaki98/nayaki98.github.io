package org.medex.service;

import org.medex.beans.Patient;

public interface PatientService {
	String registerPatient(Patient p);
	
}
